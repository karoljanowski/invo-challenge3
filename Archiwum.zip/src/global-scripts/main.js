/// Main JavaScript File
/// Here we import all the global JavaScript files we need for our project.

import '../global-styles/style.scss'